The project came from Frontend Mentor, and is the QR Code challenge. 
I used the QR code image, and the html file is in QR-Code-Desktop.html,
while the CSS file is in the QR_Code_Desktop.css. 

Feel free to reach me at lilycaicw@gmail.com for any questions or suggesstions on
how I can improve my code. Thank you!
